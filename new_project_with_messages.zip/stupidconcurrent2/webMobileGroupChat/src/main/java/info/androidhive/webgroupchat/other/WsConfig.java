package info.androidhive.webgroupchat.other;

public class WsConfig {
	public static final String URL_WEBSOCKET = "ws://10.146.18.152:8082/ChatServer/chat?name=";
}